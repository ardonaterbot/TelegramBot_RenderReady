import os
import asyncio
from dotenv import load_dotenv
from aiogram import Bot, Dispatcher
from aiogram.enums import ParseMode
from aiogram.types import Message, InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.filters import Command
from aiogram.client.default import DefaultBotProperties
import aiohttp

load_dotenv()
API_TOKEN = "8383583495:AAHPHgt6RtCLJsQE6-eEZm4vnnZIr4mLCnE"
ALLOWED_GROUP_ID = -1002767524124
OWNER_ID = 7793547660

bot = Bot(API_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher()

def join_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📢 Join Channel", url="https://t.me/motoedgelikebot")]
    ])

async def fetch_json(url):
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as r:
            if r.status == 200:
                return await r.json()
    return None

def group_only(func):
    async def wrapper(msg: Message):
        if msg.chat.id != ALLOWED_GROUP_ID:
            await msg.reply("🚫 Bot sirf authorised group me kaam karta hai.")
            return
        return await func(msg)
    return wrapper

@dp.message(Command("like"))
@group_only
async def like_handler(msg: Message):
    if msg.from_user.id != OWNER_ID:
        await msg.reply("🚫 Aap authorized user nahi ho.")
        return

    parts = msg.text.split()
    if len(parts) != 3:
        await msg.reply("❗ Format: /like bd uid", reply_markup=join_keyboard())
        return

    region, uid = parts[1].upper(), parts[2]
    if region not in ["BD", "IND"]:
        await msg.reply("❗ Sirf BD ya IND region allowed hai!", reply_markup=join_keyboard())
        return

    wait = await msg.reply("⏳ Sending 99 Likes, Please Wait...")

    url = f"https://anish-likes.vercel.app/like?server_name={region.lower()}&uid={uid}&key=jex4rrr"
    data = await fetch_json(url)

    if not data:
        await wait.edit_text("❌ Failed! UID galat ho sakta hai ya server busy hai.", reply_markup=join_keyboard())
        return

    if data.get("status") == 2:
        await wait.edit_text(
            f"🚫 Daily Max Likes Reached\n\n"
            f"👤 Name: {data.get('PlayerNickname', 'N/A')}\n"
            f"🆔 UID: {uid}\n"
            f"🌍 Region: {region}\n"
            f"❤️ Current Likes: {data.get('LikesNow', 'N/A')}",
            reply_markup=join_keyboard()
        )
        return

    await wait.edit_text(
        f"✅ 99 Likes Sent Successfully!\n\n"
        f"👤 Name: {data.get('PlayerNickname', 'N/A')}\n"
        f"🆔 UID: {uid}\n"
        f"❤️ Before: {data.get('LikesbeforeCommand', 'N/A')}\n"
        f"👍 After: {data.get('LikesafterCommand', 'N/A')}\n"
        f"🎯 Likes Sent: {data.get('LikesGivenByAPI', 'N/A')}",
        reply_markup=join_keyboard()
    )

async def main():
    print("🔐 Secure Like Bot is Running...")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())